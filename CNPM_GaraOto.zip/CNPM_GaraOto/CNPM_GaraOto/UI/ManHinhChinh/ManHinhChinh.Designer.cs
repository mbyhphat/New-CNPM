﻿namespace CNPM_GaraOto.UI.ManHinhChinh
{
    partial class ManHinhChinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            button8 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            button6 = new Button();
            button7 = new Button();
            button9 = new Button();
            tableLayoutPanel2 = new TableLayoutPanel();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 9;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.2000008F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11.1F));
            tableLayoutPanel1.Controls.Add(button8, 0, 0);
            tableLayoutPanel1.Controls.Add(button5, 4, 0);
            tableLayoutPanel1.Controls.Add(button4, 3, 0);
            tableLayoutPanel1.Controls.Add(button3, 2, 0);
            tableLayoutPanel1.Controls.Add(button2, 1, 0);
            tableLayoutPanel1.Controls.Add(button1, 0, 0);
            tableLayoutPanel1.Controls.Add(button6, 5, 0);
            tableLayoutPanel1.Controls.Add(button7, 6, 0);
            tableLayoutPanel1.Controls.Add(button9, 8, 0);
            tableLayoutPanel1.Dock = DockStyle.Top;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(1023, 62);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.ActiveCaptionText;
            button8.Dock = DockStyle.Fill;
            button8.ForeColor = SystemColors.ButtonHighlight;
            button8.Location = new Point(117, 3);
            button8.Name = "button8";
            button8.Size = new Size(107, 56);
            button8.TabIndex = 7;
            button8.Text = "Nội dung sửa chữa";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click_1;
            // 
            // button5
            // 
            button5.BackColor = SystemColors.ActiveCaptionText;
            button5.Dock = DockStyle.Fill;
            button5.ForeColor = SystemColors.ButtonHighlight;
            button5.Location = new Point(569, 3);
            button5.Name = "button5";
            button5.Size = new Size(107, 56);
            button5.TabIndex = 4;
            button5.Text = "Lập báo cáo tồn";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ActiveCaptionText;
            button4.Dock = DockStyle.Fill;
            button4.ForeColor = SystemColors.ButtonHighlight;
            button4.Location = new Point(456, 3);
            button4.Name = "button4";
            button4.Size = new Size(107, 56);
            button4.TabIndex = 3;
            button4.Text = "Vật tư phụ tùng";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ActiveCaptionText;
            button3.Dock = DockStyle.Fill;
            button3.ForeColor = SystemColors.ButtonHighlight;
            button3.Location = new Point(343, 3);
            button3.Name = "button3";
            button3.Size = new Size(107, 56);
            button3.TabIndex = 2;
            button3.Text = "Lập phiếu sửa chữa";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveCaptionText;
            button2.Dock = DockStyle.Fill;
            button2.ForeColor = SystemColors.ButtonHighlight;
            button2.Location = new Point(230, 3);
            button2.Name = "button2";
            button2.Size = new Size(107, 56);
            button2.TabIndex = 1;
            button2.Text = "Tra cứu xe";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveCaptionText;
            button1.Dock = DockStyle.Fill;
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(3, 3);
            button1.Name = "button1";
            button1.Size = new Size(108, 56);
            button1.TabIndex = 0;
            button1.Text = "Tiếp nhận xe";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.ActiveCaptionText;
            button6.Dock = DockStyle.Fill;
            button6.ForeColor = SystemColors.ButtonHighlight;
            button6.Location = new Point(682, 3);
            button6.Name = "button6";
            button6.Size = new Size(107, 56);
            button6.TabIndex = 5;
            button6.Text = "Lập báo cáo doanh thu";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.ActiveCaptionText;
            button7.Dock = DockStyle.Fill;
            button7.ForeColor = SystemColors.ButtonHighlight;
            button7.Location = new Point(795, 3);
            button7.Name = "button7";
            button7.Size = new Size(107, 56);
            button7.TabIndex = 6;
            button7.Text = "Thay đổi quy định";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.ActiveCaptionText;
            button9.Dock = DockStyle.Fill;
            button9.Font = new Font("Arial", 9F);
            button9.ForeColor = SystemColors.ButtonHighlight;
            button9.Location = new Point(908, 3);
            button9.Name = "button9";
            button9.Size = new Size(112, 56);
            button9.TabIndex = 8;
            button9.Text = " Báo cáo nhập VTPT";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 4;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 7F));
            tableLayoutPanel2.Controls.Add(label3, 2, 0);
            tableLayoutPanel2.Controls.Add(pictureBox1, 3, 0);
            tableLayoutPanel2.Dock = DockStyle.Top;
            tableLayoutPanel2.Location = new Point(0, 62);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.Size = new Size(1023, 55);
            tableLayoutPanel2.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Fill;
            label3.Font = new Font("Arial", 11F);
            label3.ForeColor = SystemColors.Highlight;
            label3.Location = new Point(615, 0);
            label3.Name = "label3";
            label3.Size = new Size(331, 55);
            label3.TabIndex = 4;
            label3.Text = "Trịnh Trần Phương Tuấn";
            label3.TextAlign = ContentAlignment.MiddleRight;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.avatar_icon_blue;
            pictureBox1.Location = new Point(952, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 49);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Dock = DockStyle.Fill;
            pictureBox2.Image = Properties.Resources.manhinhchinh;
            pictureBox2.Location = new Point(0, 117);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1023, 333);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // ManHinhChinh
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1023, 450);
            Controls.Add(pictureBox2);
            Controls.Add(tableLayoutPanel2);
            Controls.Add(tableLayoutPanel1);
            Name = "ManHinhChinh";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ManHinhChinh";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Button button1;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private TableLayoutPanel tableLayoutPanel2;
        private Label label3;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
    }   

}
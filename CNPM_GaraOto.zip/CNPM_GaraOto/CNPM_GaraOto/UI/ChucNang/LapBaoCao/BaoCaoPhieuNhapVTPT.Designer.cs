﻿namespace CNPM_GaraOto.UI.ChucNang.LapBaoCao
{
    partial class BaoCaoPhieuNhapVTPT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            panel1 = new Panel();
            dataGridView1 = new DataGridView();
            label2 = new Label();
            panel2 = new Panel();
            lbDoanhthu = new Label();
            panel3 = new Panel();
            flowLayoutPanel2 = new FlowLayoutPanel();
            textBox2 = new TextBox();
            txbStart = new TextBox();
            textBox4 = new TextBox();
            txbEnd = new TextBox();
            panel4 = new Panel();
            button1 = new Button();
            button2 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            flowLayoutPanel2.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox1.BackColor = Color.FromArgb(255, 255, 128);
            textBox1.Font = new Font("Arial", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(1, 2);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(806, 45);
            textBox1.TabIndex = 0;
            textBox1.TabStop = false;
            textBox1.Text = "BÁO CÁO NHẬP VẬT TƯ PHỤ TÙNG";
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel1.Controls.Add(dataGridView1);
            panel1.Location = new Point(-1, 89);
            panel1.Name = "panel1";
            panel1.Size = new Size(808, 372);
            panel1.TabIndex = 2;
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = SystemColors.Control;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(3, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(805, 366);
            dataGridView1.TabIndex = 0;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(7, 11);
            label2.Name = "label2";
            label2.Size = new Size(168, 21);
            label2.TabIndex = 3;
            label2.Text = "TỔNG TIỀN NHẬP:";
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel2.Controls.Add(lbDoanhthu);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(437, 464);
            panel2.Name = "panel2";
            panel2.Size = new Size(370, 55);
            panel2.TabIndex = 5;
            // 
            // lbDoanhthu
            // 
            lbDoanhthu.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbDoanhthu.AutoSize = true;
            lbDoanhthu.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbDoanhthu.Location = new Point(186, 11);
            lbDoanhthu.Name = "lbDoanhthu";
            lbDoanhthu.Size = new Size(0, 21);
            lbDoanhthu.TabIndex = 4;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel3.BackColor = SystemColors.ActiveCaption;
            panel3.Controls.Add(flowLayoutPanel2);
            panel3.Location = new Point(2, 44);
            panel3.Name = "panel3";
            panel3.Size = new Size(805, 48);
            panel3.TabIndex = 6;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            flowLayoutPanel2.Controls.Add(textBox2);
            flowLayoutPanel2.Controls.Add(txbStart);
            flowLayoutPanel2.Controls.Add(textBox4);
            flowLayoutPanel2.Controls.Add(txbEnd);
            flowLayoutPanel2.Location = new Point(134, 0);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(537, 48);
            flowLayoutPanel2.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox2.BackColor = SystemColors.ActiveCaption;
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(3, 3);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(125, 21);
            textBox2.TabIndex = 0;
            textBox2.Text = "Từ ";
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // txbStart
            // 
            txbStart.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txbStart.BackColor = SystemColors.ActiveCaption;
            txbStart.BorderStyle = BorderStyle.None;
            txbStart.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txbStart.Location = new Point(134, 3);
            txbStart.Name = "txbStart";
            txbStart.ReadOnly = true;
            txbStart.Size = new Size(125, 21);
            txbStart.TabIndex = 1;
            txbStart.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            textBox4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox4.BackColor = SystemColors.ActiveCaption;
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.Location = new Point(265, 3);
            textBox4.Name = "textBox4";
            textBox4.ReadOnly = true;
            textBox4.Size = new Size(125, 21);
            textBox4.TabIndex = 2;
            textBox4.Text = "đến ";
            textBox4.TextAlign = HorizontalAlignment.Center;
            // 
            // txbEnd
            // 
            txbEnd.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txbEnd.BackColor = SystemColors.ActiveCaption;
            txbEnd.BorderStyle = BorderStyle.None;
            txbEnd.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txbEnd.Location = new Point(396, 3);
            txbEnd.Name = "txbEnd";
            txbEnd.ReadOnly = true;
            txbEnd.Size = new Size(125, 21);
            txbEnd.TabIndex = 3;
            txbEnd.TextAlign = HorizontalAlignment.Center;
            // 
            // panel4
            // 
            panel4.Controls.Add(button1);
            panel4.Controls.Add(button2);
            panel4.Location = new Point(444, 525);
            panel4.Name = "panel4";
            panel4.Size = new Size(363, 67);
            panel4.TabIndex = 7;
            // 
            // button1
            // 
            button1.BackColor = Color.DodgerBlue;
            button1.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(3, 9);
            button1.Name = "button1";
            button1.Size = new Size(131, 46);
            button1.TabIndex = 3;
            button1.Text = "In báo cáo";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button2.BackColor = SystemColors.ActiveCaptionText;
            button2.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(214, 9);
            button2.Name = "button2";
            button2.Size = new Size(94, 46);
            button2.TabIndex = 2;
            button2.Text = "Quay lại";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // BaoCaoPhieuNhapVTPT
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(810, 592);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(textBox1);
            Name = "BaoCaoPhieuNhapVTPT";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Báo Cáo Doanh Thu";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            flowLayoutPanel2.ResumeLayout(false);
            flowLayoutPanel2.PerformLayout();
            panel4.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Panel panel1;
        private DataGridView dataGridView1;
        private Label label2;
        private Panel panel2;
        private Label lbDoanhthu;
        private Panel panel3;
        private FlowLayoutPanel flowLayoutPanel2;
        private TextBox textBox2;
        private TextBox txbStart;
        private TextBox textBox4;
        private TextBox txbEnd;
        private Panel panel4;
        private Button button1;
        private Button button2;
    }
}

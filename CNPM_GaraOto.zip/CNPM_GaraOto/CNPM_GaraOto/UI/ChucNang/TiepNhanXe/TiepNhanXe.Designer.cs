﻿namespace CNPM_GaraOto.UI.ChucNang.TiepNhanXe
{
    partial class TiepNhanXe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            text_TenChuXe = new TextBox();
            text_BienSoXe = new TextBox();
            text_DiaChi = new TextBox();
            text_NgayTiepNhan = new TextBox();
            text_SoDienThoai = new TextBox();
            label_TiepNhanXe = new Label();
            label_TenChuXe = new Label();
            label_BienSoXe = new Label();
            label_HieuXe = new Label();
            label_DiaChi = new Label();
            label_SoDienThoai = new Label();
            label_NgayTiepNhan = new Label();
            button_XacNhan = new Button();
            button1 = new Button();
            contextMenuStrip1 = new ContextMenuStrip(components);
            label1 = new Label();
            text_Email = new TextBox();
            comboBox_HieuXe = new ComboBox();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            SuspendLayout();
            // 
            // text_TenChuXe
            // 
            text_TenChuXe.Font = new Font("Arial", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            text_TenChuXe.ForeColor = Color.Black;
            text_TenChuXe.Location = new Point(189, 68);
            text_TenChuXe.Name = "text_TenChuXe";
            text_TenChuXe.Size = new Size(400, 36);
            text_TenChuXe.TabIndex = 0;
            // 
            // text_BienSoXe
            // 
            text_BienSoXe.Font = new Font("Arial", 15F);
            text_BienSoXe.ForeColor = Color.Black;
            text_BienSoXe.Location = new Point(189, 131);
            text_BienSoXe.Name = "text_BienSoXe";
            text_BienSoXe.Size = new Size(400, 36);
            text_BienSoXe.TabIndex = 1;
            // 
            // text_DiaChi
            // 
            text_DiaChi.Font = new Font("Arial", 15F);
            text_DiaChi.ForeColor = Color.Black;
            text_DiaChi.Location = new Point(189, 257);
            text_DiaChi.Name = "text_DiaChi";
            text_DiaChi.Size = new Size(400, 36);
            text_DiaChi.TabIndex = 3;
            // 
            // text_NgayTiepNhan
            // 
            text_NgayTiepNhan.Font = new Font("Arial", 15F);
            text_NgayTiepNhan.ForeColor = Color.Black;
            text_NgayTiepNhan.Location = new Point(189, 446);
            text_NgayTiepNhan.Name = "text_NgayTiepNhan";
            text_NgayTiepNhan.Size = new Size(400, 36);
            text_NgayTiepNhan.TabIndex = 6;
            // 
            // text_SoDienThoai
            // 
            text_SoDienThoai.Font = new Font("Arial", 15F);
            text_SoDienThoai.ForeColor = Color.Black;
            text_SoDienThoai.Location = new Point(189, 320);
            text_SoDienThoai.Name = "text_SoDienThoai";
            text_SoDienThoai.Size = new Size(400, 36);
            text_SoDienThoai.TabIndex = 4;
            // 
            // label_TiepNhanXe
            // 
            label_TiepNhanXe.AutoSize = true;
            label_TiepNhanXe.Font = new Font("Arial", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label_TiepNhanXe.Location = new Point(281, 9);
            label_TiepNhanXe.Name = "label_TiepNhanXe";
            label_TiepNhanXe.Size = new Size(254, 40);
            label_TiepNhanXe.TabIndex = 8;
            label_TiepNhanXe.Text = "TIẾP NHẬN XE";
            // 
            // label_TenChuXe
            // 
            label_TenChuXe.AutoSize = true;
            label_TenChuXe.Font = new Font("Arial", 10F);
            label_TenChuXe.ForeColor = Color.FromArgb(130, 130, 130);
            label_TenChuXe.Location = new Point(189, 49);
            label_TenChuXe.Name = "label_TenChuXe";
            label_TenChuXe.Size = new Size(89, 19);
            label_TenChuXe.TabIndex = 9;
            label_TenChuXe.Text = "Tên chủ xe";
            // 
            // label_BienSoXe
            // 
            label_BienSoXe.AutoSize = true;
            label_BienSoXe.Font = new Font("Arial", 10F);
            label_BienSoXe.ForeColor = Color.FromArgb(130, 130, 130);
            label_BienSoXe.Location = new Point(189, 112);
            label_BienSoXe.Name = "label_BienSoXe";
            label_BienSoXe.Size = new Size(85, 19);
            label_BienSoXe.TabIndex = 10;
            label_BienSoXe.Text = "Biển số xe";
            // 
            // label_HieuXe
            // 
            label_HieuXe.AutoSize = true;
            label_HieuXe.Font = new Font("Arial", 10F);
            label_HieuXe.ForeColor = Color.FromArgb(130, 130, 130);
            label_HieuXe.Location = new Point(189, 175);
            label_HieuXe.Name = "label_HieuXe";
            label_HieuXe.Size = new Size(63, 19);
            label_HieuXe.TabIndex = 11;
            label_HieuXe.Text = "Hiệu xe";
            // 
            // label_DiaChi
            // 
            label_DiaChi.AutoSize = true;
            label_DiaChi.Font = new Font("Arial", 10F);
            label_DiaChi.ForeColor = Color.FromArgb(130, 130, 130);
            label_DiaChi.Location = new Point(189, 238);
            label_DiaChi.Name = "label_DiaChi";
            label_DiaChi.Size = new Size(61, 19);
            label_DiaChi.TabIndex = 12;
            label_DiaChi.Text = "Địa chỉ";
            // 
            // label_SoDienThoai
            // 
            label_SoDienThoai.AutoSize = true;
            label_SoDienThoai.Font = new Font("Arial", 10F);
            label_SoDienThoai.ForeColor = Color.FromArgb(130, 130, 130);
            label_SoDienThoai.Location = new Point(189, 301);
            label_SoDienThoai.Name = "label_SoDienThoai";
            label_SoDienThoai.Size = new Size(106, 19);
            label_SoDienThoai.TabIndex = 13;
            label_SoDienThoai.Text = "Số điện thoại";
            // 
            // label_NgayTiepNhan
            // 
            label_NgayTiepNhan.AutoSize = true;
            label_NgayTiepNhan.Font = new Font("Arial", 10F);
            label_NgayTiepNhan.ForeColor = Color.FromArgb(130, 130, 130);
            label_NgayTiepNhan.Location = new Point(189, 427);
            label_NgayTiepNhan.Name = "label_NgayTiepNhan";
            label_NgayTiepNhan.Size = new Size(267, 19);
            label_NgayTiepNhan.TabIndex = 14;
            label_NgayTiepNhan.Text = "Ngày tiếp nhận (Ví dụ: 2024/12/04)";
            // 
            // button_XacNhan
            // 
            button_XacNhan.BackColor = Color.FromArgb(66, 133, 244);
            button_XacNhan.Font = new Font("Arial", 16F);
            button_XacNhan.ForeColor = Color.White;
            button_XacNhan.Location = new Point(189, 505);
            button_XacNhan.Name = "button_XacNhan";
            button_XacNhan.Size = new Size(400, 47);
            button_XacNhan.TabIndex = 7;
            button_XacNhan.Text = "XÁC NHẬN";
            button_XacNhan.UseVisualStyleBackColor = false;
            button_XacNhan.Click += button_XacNhan_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.Font = new Font("Arial", 16F);
            button1.ForeColor = Color.White;
            button1.Location = new Point(189, 558);
            button1.Name = "button1";
            button1.Size = new Size(400, 45);
            button1.TabIndex = 8;
            button1.Text = "ĐÓNG";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(40, 40);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 10F);
            label1.ForeColor = Color.FromArgb(130, 130, 130);
            label1.Location = new Point(189, 364);
            label1.Name = "label1";
            label1.Size = new Size(49, 19);
            label1.TabIndex = 18;
            label1.Text = "Email";
            // 
            // text_Email
            // 
            text_Email.Font = new Font("Arial", 15F);
            text_Email.ForeColor = Color.Black;
            text_Email.Location = new Point(189, 383);
            text_Email.Name = "text_Email";
            text_Email.Size = new Size(400, 36);
            text_Email.TabIndex = 5;
            // 
            // comboBox_HieuXe
            // 
            comboBox_HieuXe.Font = new Font("Arial", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox_HieuXe.FormattingEnabled = true;
            comboBox_HieuXe.Location = new Point(189, 194);
            comboBox_HieuXe.Name = "comboBox_HieuXe";
            comboBox_HieuXe.Size = new Size(400, 36);
            comboBox_HieuXe.TabIndex = 2;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.User_TNX;
            pictureBox1.Location = new Point(144, 57);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(45, 45);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 19;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Paste_TNX;
            pictureBox2.Location = new Point(144, 121);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(45, 45);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 20;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.car_13260;
            pictureBox3.Location = new Point(144, 180);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(45, 45);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 21;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.location_pin_place_map_address_placeholder_icon_149101;
            pictureBox4.Location = new Point(144, 245);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(45, 45);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 22;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.phone_call_auricular_symbol_in_black_icon_icons_com_56483;
            pictureBox5.Location = new Point(141, 305);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(45, 45);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 23;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.date_3598;
            pictureBox6.Location = new Point(141, 433);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(45, 45);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 24;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.mail_TNX;
            pictureBox7.Location = new Point(144, 375);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(45, 45);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 25;
            pictureBox7.TabStop = false;
            // 
            // TiepNhanXe
            // 
            AutoScaleMode = AutoScaleMode.None;
            AutoSize = true;
            ClientSize = new Size(788, 604);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(comboBox_HieuXe);
            Controls.Add(label1);
            Controls.Add(text_Email);
            Controls.Add(button1);
            Controls.Add(button_XacNhan);
            Controls.Add(label_NgayTiepNhan);
            Controls.Add(label_SoDienThoai);
            Controls.Add(label_DiaChi);
            Controls.Add(label_HieuXe);
            Controls.Add(label_BienSoXe);
            Controls.Add(label_TenChuXe);
            Controls.Add(label_TiepNhanXe);
            Controls.Add(text_NgayTiepNhan);
            Controls.Add(text_SoDienThoai);
            Controls.Add(text_DiaChi);
            Controls.Add(text_BienSoXe);
            Controls.Add(text_TenChuXe);
            Font = new Font("Arial", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Name = "TiepNhanXe";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tiếp Nhận Xe";
            Load += TiepNhanXe_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox text_TenChuXe;
        private TextBox text_BienSoXe;
        private TextBox text_DiaChi;
        private TextBox text_NgayTiepNhan;
        private TextBox text_SoDienThoai;
        private Label label_TiepNhanXe;
        private Label label_TenChuXe;
        private Label label_BienSoXe;
        private Label label_HieuXe;
        private Label label_DiaChi;
        private Label label_SoDienThoai;
        private Label label_NgayTiepNhan;
        private Button button_XacNhan;
        private Button button1;
        private ContextMenuStrip contextMenuStrip1;
        private Label label1;
        private TextBox text_Email;
        private ComboBox comboBox_HieuXe;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
    }
}
﻿namespace CNPM_GaraOto.UI.ChucNang.TraCuuXe
{
    partial class ThongTinXe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblThongTinXe = new Label();
            pnThongtinchung = new Panel();
            textBox6 = new TextBox();
            txbSDT = new TextBox();
            txbDiachi = new TextBox();
            textBox3 = new TextBox();
            txbBienSo = new TextBox();
            txbHoten = new TextBox();
            button1 = new Button();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label1 = new Label();
            label2 = new Label();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox1 = new PictureBox();
            lblThongtinchung = new Label();
            panel2 = new Panel();
            dvgtThongTinXe = new DataGridView();
            button2 = new Button();
            button5 = new Button();
            pnThongtinchung.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dvgtThongTinXe).BeginInit();
            SuspendLayout();
            // 
            // lblThongTinXe
            // 
            lblThongTinXe.AutoEllipsis = true;
            lblThongTinXe.BackColor = SystemColors.ActiveBorder;
            lblThongTinXe.Font = new Font("Arial Narrow", 20.1F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblThongTinXe.Location = new Point(-1, -1);
            lblThongTinXe.Margin = new Padding(1, 0, 1, 0);
            lblThongTinXe.Name = "lblThongTinXe";
            lblThongTinXe.Size = new Size(1251, 53);
            lblThongTinXe.TabIndex = 0;
            lblThongTinXe.Text = "THÔNG TIN XE ";
            lblThongTinXe.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnThongtinchung
            // 
            pnThongtinchung.Controls.Add(textBox6);
            pnThongtinchung.Controls.Add(txbSDT);
            pnThongtinchung.Controls.Add(txbDiachi);
            pnThongtinchung.Controls.Add(textBox3);
            pnThongtinchung.Controls.Add(txbBienSo);
            pnThongtinchung.Controls.Add(txbHoten);
            pnThongtinchung.Controls.Add(button1);
            pnThongtinchung.Controls.Add(label6);
            pnThongtinchung.Controls.Add(label5);
            pnThongtinchung.Controls.Add(label4);
            pnThongtinchung.Controls.Add(label3);
            pnThongtinchung.Controls.Add(label1);
            pnThongtinchung.Controls.Add(label2);
            pnThongtinchung.Controls.Add(pictureBox7);
            pnThongtinchung.Controls.Add(pictureBox6);
            pnThongtinchung.Controls.Add(pictureBox5);
            pnThongtinchung.Controls.Add(pictureBox4);
            pnThongtinchung.Controls.Add(pictureBox3);
            pnThongtinchung.Controls.Add(pictureBox1);
            pnThongtinchung.Controls.Add(lblThongtinchung);
            pnThongtinchung.Location = new Point(1, 98);
            pnThongtinchung.Margin = new Padding(1);
            pnThongtinchung.Name = "pnThongtinchung";
            pnThongtinchung.Size = new Size(221, 516);
            pnThongtinchung.TabIndex = 1;
            pnThongtinchung.Paint += panel1_Paint;
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox6.Location = new Point(65, 447);
            textBox6.Margin = new Padding(1);
            textBox6.Name = "textBox6";
            textBox6.ReadOnly = true;
            textBox6.Size = new Size(155, 28);
            textBox6.TabIndex = 25;
            // 
            // txbSDT
            // 
            txbSDT.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txbSDT.Location = new Point(66, 371);
            txbSDT.Margin = new Padding(1);
            txbSDT.Name = "txbSDT";
            txbSDT.Size = new Size(154, 28);
            txbSDT.TabIndex = 24;
            // 
            // txbDiachi
            // 
            txbDiachi.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txbDiachi.Location = new Point(65, 296);
            txbDiachi.Margin = new Padding(1);
            txbDiachi.Name = "txbDiachi";
            txbDiachi.Size = new Size(155, 28);
            txbDiachi.TabIndex = 23;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Arial", 9.900001F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(66, 226);
            textBox3.Margin = new Padding(1);
            textBox3.Name = "textBox3";
            textBox3.ReadOnly = true;
            textBox3.Size = new Size(154, 26);
            textBox3.TabIndex = 22;
            // 
            // txbBienSo
            // 
            txbBienSo.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txbBienSo.Location = new Point(66, 163);
            txbBienSo.Margin = new Padding(1);
            txbBienSo.Name = "txbBienSo";
            txbBienSo.ReadOnly = true;
            txbBienSo.Size = new Size(154, 28);
            txbBienSo.TabIndex = 21;
            // 
            // txbHoten
            // 
            txbHoten.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txbHoten.Location = new Point(66, 86);
            txbHoten.Margin = new Padding(1);
            txbHoten.Name = "txbHoten";
            txbHoten.Size = new Size(154, 28);
            txbHoten.TabIndex = 5;
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(1, 484);
            button1.Margin = new Padding(1);
            button1.Name = "button1";
            button1.Size = new Size(219, 31);
            button1.TabIndex = 20;
            button1.Text = "Thay đổi thông tin ";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(65, 409);
            label6.Margin = new Padding(1, 0, 1, 0);
            label6.Name = "label6";
            label6.Size = new Size(131, 21);
            label6.TabIndex = 13;
            label6.Text = "Ngày tiếp nhận";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(65, 129);
            label5.Margin = new Padding(1, 0, 1, 0);
            label5.Name = "label5";
            label5.Size = new Size(98, 21);
            label5.TabIndex = 12;
            label5.Text = "Biển số xe ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(65, 264);
            label4.Margin = new Padding(1, 0, 1, 0);
            label4.Name = "label4";
            label4.Size = new Size(65, 21);
            label4.TabIndex = 12;
            label4.Text = "Địa chỉ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(66, 199);
            label3.Margin = new Padding(1, 0, 1, 0);
            label3.Name = "label3";
            label3.Size = new Size(70, 21);
            label3.TabIndex = 12;
            label3.Text = "Hiệu xe";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(65, 342);
            label1.Margin = new Padding(1, 0, 1, 0);
            label1.Name = "label1";
            label1.Size = new Size(115, 21);
            label1.TabIndex = 11;
            label1.Text = "Số điện thoại";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(65, 55);
            label2.Margin = new Padding(1, 0, 1, 0);
            label2.Name = "label2";
            label2.Size = new Size(104, 21);
            label2.TabIndex = 10;
            label2.Text = "Tên chủ xe ";
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.date_3598;
            pictureBox7.Location = new Point(1, 441);
            pictureBox7.Margin = new Padding(1);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(46, 32);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 9;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.location_pin_place_map_address_placeholder_icon_149101;
            pictureBox6.Location = new Point(1, 292);
            pictureBox6.Margin = new Padding(1);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(46, 32);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 8;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.note_list_icon_124054;
            pictureBox5.Location = new Point(1, 159);
            pictureBox5.Margin = new Padding(1);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(46, 32);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 7;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.car_13260;
            pictureBox4.Location = new Point(1, 220);
            pictureBox4.Margin = new Padding(1);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(46, 32);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 6;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.phone_call_auricular_symbol_in_black_icon_icons_com_56483;
            pictureBox3.Location = new Point(1, 367);
            pictureBox3.Margin = new Padding(1);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(46, 32);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 5;
            pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.user_icon_153312;
            pictureBox1.Location = new Point(1, 82);
            pictureBox1.Margin = new Padding(1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(46, 32);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // lblThongtinchung
            // 
            lblThongtinchung.BackColor = SystemColors.ActiveBorder;
            lblThongtinchung.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblThongtinchung.Location = new Point(0, 0);
            lblThongtinchung.Margin = new Padding(1, 0, 1, 0);
            lblThongtinchung.Name = "lblThongtinchung";
            lblThongtinchung.Size = new Size(220, 37);
            lblThongtinchung.TabIndex = 2;
            lblThongtinchung.Text = "Thông tin chung";
            lblThongtinchung.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            panel2.Controls.Add(dvgtThongTinXe);
            panel2.Controls.Add(button2);
            panel2.Location = new Point(281, 98);
            panel2.Margin = new Padding(1);
            panel2.Name = "panel2";
            panel2.Size = new Size(969, 449);
            panel2.TabIndex = 3;
            panel2.Paint += panel2_Paint;
            // 
            // dvgtThongTinXe
            // 
            dvgtThongTinXe.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dvgtThongTinXe.BackgroundColor = SystemColors.ButtonHighlight;
            dvgtThongTinXe.BorderStyle = BorderStyle.None;
            dvgtThongTinXe.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dvgtThongTinXe.Location = new Point(1, 1);
            dvgtThongTinXe.Margin = new Padding(1);
            dvgtThongTinXe.Name = "dvgtThongTinXe";
            dvgtThongTinXe.RowHeadersWidth = 102;
            dvgtThongTinXe.Size = new Size(967, 398);
            dvgtThongTinXe.TabIndex = 3;
            // 
            // button2
            // 
            button2.BackColor = Color.CornflowerBlue;
            button2.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = SystemColors.ButtonHighlight;
            button2.Location = new Point(0, 409);
            button2.Margin = new Padding(1);
            button2.Name = "button2";
            button2.Size = new Size(135, 39);
            button2.TabIndex = 1;
            button2.Text = "Thêm";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.CornflowerBlue;
            button5.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button5.ForeColor = SystemColors.ButtonHighlight;
            button5.Location = new Point(1073, 549);
            button5.Margin = new Padding(1);
            button5.Name = "button5";
            button5.Size = new Size(177, 74);
            button5.TabIndex = 4;
            button5.Text = "Thanh toán ";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // ThongTinXe
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(1251, 624);
            Controls.Add(button5);
            Controls.Add(panel2);
            Controls.Add(pnThongtinchung);
            Controls.Add(lblThongTinXe);
            ForeColor = SystemColors.ActiveCaptionText;
            Margin = new Padding(1);
            Name = "ThongTinXe";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ThongTinXe";
            pnThongtinchung.ResumeLayout(false);
            pnThongtinchung.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dvgtThongTinXe).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label lblThongTinXe;
        private Panel pnThongtinchung;
        private Label lblThongtinchung;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label1;
        private Label label2;
        private Button button1;
        private Panel panel2;
        private Button button2;
        private Button button5;
        private DataGridView dvgtThongTinXe;
        private TextBox textBox6;
        private TextBox txbSDT;
        private TextBox txbDiachi;
        private TextBox textBox3;
        private TextBox txbBienSo;
        private TextBox txbHoten;
    }
}